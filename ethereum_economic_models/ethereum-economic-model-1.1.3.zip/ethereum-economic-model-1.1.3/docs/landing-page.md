# Landing Page

Welcome to the CADLabs Ethereum Research Model!

Get started by visiting:
* The CADLabs Ethereum Research Model GitHub repo: https://github.com/CADLabs/ethereum-model
* The model code documentation generated from Python docstrings: <a href="model/index.html">Model Documentation</a>
