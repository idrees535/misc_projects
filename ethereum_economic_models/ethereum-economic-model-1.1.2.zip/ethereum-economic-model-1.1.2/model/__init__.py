"""
CADLabs Ethereum Economic Model package & version
"""
__version__ = "1.1.2"
